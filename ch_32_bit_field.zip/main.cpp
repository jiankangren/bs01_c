
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

union UnionT
{
	int a;
	unsigned char	pBit[4];
};



struct SBitField
{
	char a1: 8;		// 8 bit
	char a2: 8;		// 8 bit
	char a3: 8;		// 8 bit
	char a4: 8;		// 8 bit
};



int main()
{
	UnionT t;

	t.a = 0x12345678;

	printf("Union�� Bit\n");
	printf("%x %x %x %x\n", t.pBit[0], t.pBit[1], t.pBit[2], t.pBit[3]);

	printf("\n\n");
	printf("Struct�� BitField\n");

	SBitField s;


	printf("sizeof SBitField: %d\n", sizeof(SBitField));

	s.a1 =0x12;
	s.a2 =0x34;
	s.a3 =0x56;
	s.a4 =0x76;

	int c;

	memcpy(&c, &s, sizeof(int));

	printf("%x\n", c);

	return 0;
}
