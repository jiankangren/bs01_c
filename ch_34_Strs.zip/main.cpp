#include <memory.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void Memcpy();
void Memmove();
void Memccpy();
void Memchr();

void StrSpn();
void StrCspn();
void StrUp();
void StrLwr();
void StrUpr();
void StrPbrk();
void StrRev();
void StrTok();


void main()
{
	printf("MSDN�� �ִ� ������ �ҽ���...\n");

	Memcpy();
	Memmove();
	Memccpy();
	Memchr();

	StrSpn();
	StrCspn();
	StrUp();
	StrLwr();

	StrUpr();
	StrPbrk();
	StrRev();
	StrTok();
}


void Memcpy()
{
	printf("-------------------------memcpy-------------------------\n");

	//                            1         2         3         4         5
	//                  012345678901234567890123456789012345678901234567890
	char string1[60] = "The quick brown dog jumps over the lazy fox";
	char string2[60] = "The quick brown fox jumps over the lazy dog";

	printf( "Src: %s\n", string1);
	memcpy( string1 + 16, string1 + 40, 3 );
	printf( "Dst: %s\n", string1);
	
	printf( "Src: %s\n", string1);
	memcpy( string1 + 16, string2 + 40, 3 );
	printf( "Dst: %s\n", string1);
}



void Memmove()
{
	printf("-------------------------memmove-------------------------\n");

	//                            1         2         3         4         5
	//                  012345678901234567890123456789012345678901234567890
	char string1[60] = "The quick brown dog jumps over the lazy fox";
	char string2[60] = "The quick brown fox jumps over the lazy dog";

	printf( "Src: %s\n", string2);
	memmove( string2 + 20, string2 + 4, 40 );
	printf( "Dst: %s\n", string2);
}


void Memccpy()
{
	printf("-------------------------memccpy-------------------------\n");

	//                            1         2         3         4         5
	//                  012345678901234567890123456789012345678901234567890
	char string1[60] = "The quick brown dog jumps over the lazy fox";
	char string2[60] = "The quick brown fox jumps over the lazy dog";

	char *dst;	
	char buf[61];
	
	printf( "Src: %s\n", string1 );
	dst = (char*)memccpy( buf, string1+20, 'o', sizeof buf -1);
	*dst= '\0';
	
	printf( "Buf: %s\n", buf);
	printf( "Len: %d\n\n", strlen(buf) );
}



void Memchr()
{
	printf("-------------------------memchr-------------------------\n");

	//                            1         2         3         4         5
	//                  012345678901234567890123456789012345678901234567890
	char string1[60] = "The quick brown dog jumps over the lazy fox";
	char string2[60] = "The quick brown fox jumps over the lazy dog";

	char *dst;	
	char  ch = 'r';
	
	dst = (char*)memchr( string1+15, ch, sizeof string1);
	int r = dst - string1;
	
	if(dst)
		printf( "Result: %c found at position %d\n\n", ch, r);
}


void StrSpn()
{
	printf("-------------------------strspn-------------------------\n");

	char string[] = "cabbage";
	int  result;
	result = strspn( string, "abc" );
	printf( "The portion of '%s' containing only a, b, or c is %d bytes long\n", string, result );
}



void StrCspn()
{
	printf("-------------------------strcspn-------------------------\n");

	char string[] = "xyzabc";
	int  pos;
	
	pos = strcspn( string, "abc" );
	printf( "First a, b or c in %s is at character %d\n",  string, pos );
}



void StrUp()
{
	printf("-------------------------_strdup-------------------------\n");
	
	char buffer[] = "This is the buffer text";
	char *newstring;

	printf( "Original: %s\n", buffer );
	newstring = _strdup( buffer );
	printf( "Copy: %s\n", newstring );
	free( newstring );
}


void StrLwr()
{
	printf("-------------------------strlwr-------------------------\n");

	char string[100] = "The String to End All Strings!";
	char *copy1;
	copy1 = _strlwr( _strdup( string ) );
	
	printf( "Mixed: %s\n", string );
	printf( "Lower: %s\n", copy1 );
}

void StrUpr()
{
	printf("-------------------------strupr-------------------------\n");

	char string[100] = "The String to End All Strings!";
	char *copy2;
	copy2 = _strupr( _strdup( string ) );
	printf( "Mixed: %s\n", string );
	printf( "Upper: %s\n", copy2 );
}




void StrPbrk()
{
	printf("-------------------------strpbrk-------------------------\n");

	char string[100] = "The 3 men and 2 boys ate 5 pigs\n";
	char *result;
	/* Return pointer to first 'a' or 'b' in "string" */
	printf( "1: %s\n", string );
	result = strpbrk( string, "0123456789" );
	printf( "2: %s\n", result++ );
	result = strpbrk( result, "0123456789" );
	printf( "3: %s\n", result++ );
	result = strpbrk( result, "0123456789" );
	printf( "4: %s\n", result );
}



void StrRev()
{
	printf("-------------------------strrev-------------------------\n");

	char string[100];
	int result;
	
	printf( "Input a string and I will tell you if it is a palindrome:\n" );
	gets( string );
	
	/* Reverse string and compare (ignore case): */
	result = _stricmp( string, _strrev( _strdup( string ) ) );

	if( result == 0 )
		printf( "The string \"%s\" is a palindrome\n\n", string );
	else
		printf( "The string \"%s\" is not a palindrome\n\n", string );
}




void StrTok()
{
	printf("-------------------------strtok-------------------------\n");

	char string[] = "A string\tof ,,tokens\nand some  more tokens";
	char seps[]   = " ,\t\n";
	char *token;

	printf( "%s\n\nTokens:\n", string );

	// Establish string and get the first token:

	token = strtok( string, seps );
	
	while( token != NULL )
	{
		// While there are tokens in "string"
		printf( " %s\n", token );

		// Get next token:
		token = strtok( NULL, seps );
	}
}

