

#include <stdio.h>
#include <stdlib.h>

// Directory Header File
#include <direct.h>

#ifndef MAX_PATH
#	define MAX_PATH	260
#endif


char*	stName[] =
{
	"A_20071002",
	"A_20071012",
	"B_20071026",
	"A_20071061",
	"A_20071121",
	"C_20071033",
	"B_20071008",
	"C_20071065",
	"B_20071076",
	"",
};

void main()
{
	int		i = -1;
	char	SrcFile[] ="TestFile.txt";
	FILE*	fSrc = NULL;
	FILE*	fDst = NULL;
	int		iRead = NULL;
	void*	pSrc=NULL;


	fSrc = fopen( SrcFile, "rb");

	if(NULL == fSrc)
	{
		printf("���� ������ �� �� �����ϴ�.\n");
		return;
	}


	fseek(fSrc, 0, SEEK_END);
	iRead = ftell(fSrc);
	fseek(fSrc, 0, SEEK_SET);

	pSrc = malloc(iRead);

	fread(pSrc, 1, iRead, fSrc);
	fclose(fSrc);


	while(stName[++i])
	{
		char	sFold[MAX_PATH]={0};
		char	sFile[MAX_PATH]={0};

		sprintf(sFold,"%s", stName[i]);

		if( 0 == _mkdir( sFold ) != 0 )
		{
			printf("%s Folder Creation Succeeded\n", sFold);

			sprintf(sFile, "%s/%s.cpp", sFold, stName[i]);

			fDst = fopen(sFile, "wb");

			if(NULL == fDst)
			{
				printf("���� ������ ������ �� �����ϴ�.\n");
				continue;
			}

			fwrite(pSrc, 1, iRead, fDst);
			fclose(fDst);

			printf("Copy Succeeded\n");
		}
		else
		{
			printf("Create Folder Failed\n");
			break;
		}
	}

}

