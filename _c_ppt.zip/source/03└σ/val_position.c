/* val_position.c */
#include <stdio.h>

int main(void)
{
	int a;
	int b;

	a=10;
	b=20;

	printf("%d %d \n", a, b);	
	return 0;
}