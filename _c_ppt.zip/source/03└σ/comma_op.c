/* comma_op.c */
#include <stdio.h>

int main(void)
{
	int a=1, b=2;
	
	printf("Hello "), printf("World! \n");

	a++, b++;

	printf("%d ", a), printf("%d ", b), printf("\n");

	return 0;
}
