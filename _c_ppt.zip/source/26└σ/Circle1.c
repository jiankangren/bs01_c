/* Circle1.c */
	
#include <stdio.h>
#define PI 3.1415

int main (void)
{	
	double area;
	double radius;

	fputs("������ : ", stdout);
	scanf("%lf", &radius);

	area=radius*radius*PI;	
	printf("���̴� %f �Դϴ� \n", area);
	
	return 0;
}	
