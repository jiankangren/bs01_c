/* str_con.c*/
#include <stdio.h>

int main()
{
	char * str="AAA" "BBB";
	
	puts(str);
	puts("EEE" "FFF");

	return 0;
}