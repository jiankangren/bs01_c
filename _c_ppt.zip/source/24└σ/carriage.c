/* carriage.c */
#include <stdio.h>

int main()
{
	printf("ABCDEFG \r");
	printf("1234567   ");

	return 0;
}
