/* arr2_name.c */
#include <stdio.h>

int main(void)
{
	int a[3][2]={1, 2, 3, 4, 5, 6};

	printf("a   : %d \n", a);
	printf("a+1 : %d \n", a+1);
	printf("a+2 : %d \n", a+2);

	return 0;
}
