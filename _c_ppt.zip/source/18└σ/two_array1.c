/* two_array1.c */
#include <stdio.h>
int main(void)
{
	int a[3][2];

	printf("a[0] : %d \n", a[0]);
	printf("a[1] : %d \n", a[1]);
	printf("a[2] : %d \n", a[2]);

	printf("a    : %d \n", a);
	
	return 0;
}
	