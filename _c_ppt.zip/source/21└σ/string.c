/* string.c */

#include <stdio.h>

int main()
{
	char * str1 = "Hello Everyone!";
	char str2[] = "Hello Everyone!";

	str1[0]='A';
	str2[0]='A';

	return 0;
}
