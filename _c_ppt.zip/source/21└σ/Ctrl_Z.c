/* Ctrl_Z.c*/
	
#include <stdio.h>

int main()
{
	char ch=0;
	
	while(ch != EOF)
	{
		ch=getchar();
		putchar(ch);
	}

	printf("program ���� \n");

	return 0;
}
