/* char_IO.c*/

#include <stdio.h>

int main()
{
	char ch=0;
	
	while(ch != 'q')
	{
		ch=getchar();
		putchar(ch);	
	}

	return 0;
}
