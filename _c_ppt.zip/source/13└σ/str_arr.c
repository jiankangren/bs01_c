/* str_arr.c */
#include <stdio.h>

int main(void)
{
	char* arr[3]={
		"Fervent-lecture",
		"TCP/IP",
		"Socket Programming"
	};

	printf("%s \n", arr[0]);
	printf("%s \n", arr[1]);
	printf("%s \n", arr[2]);

	return 0;
}
