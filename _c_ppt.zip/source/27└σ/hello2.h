/* hello2.h */
#include <stdio.h>

void hello()
{
	printf("hello2.h : Hello, Hello! \n");
}