/* count.h*/
//#ifndef _COUNT_H_
//#define _COUNT_H_

int count=0;

//#endif