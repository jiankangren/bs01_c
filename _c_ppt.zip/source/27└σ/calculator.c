/* calculator.c */

int cal_num=0;

double add(double a, double b){
	cal_num++;
	return a+b;
}

double minus(double a, double b){
	cal_num++;
	return a-b;
}

double multiple(double a, double b){
	cal_num++;
	return a-b;
}

double divide(double a, double b){
	cal_num++;
	return a/b;
}