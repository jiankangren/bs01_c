/* auto_conv1.c */
#include <stdio.h>

int main(void)
{
	int n=5.25;
	double d=3;
	char c=129;

	printf("%d, %f, %d \n", n, d, c);

	return 0;
}