/* pointer1.c */
#include <stdio.h>

int main(void)
{
	int a=2005;
	int* pA=&a;


	printf("pA : %d \n", pA);
	printf("&a : %d \n", &a);

	(*pA)++;	//a++�� ���� �ǹ̸� ���Ѵ�.

	printf("a   : %d \n", a);
	printf("*pA : %d \n", *pA);

	return 0;
}