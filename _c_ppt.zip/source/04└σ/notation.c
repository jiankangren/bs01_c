/* notation.c */
#include <stdio.h>

int main(void)
{		
	int a=0xa7;
	int b=0x43;

	int c=032;
	int d=024;

	printf("16���� 0xa7 : %d \n", a);
	printf("16���� 0x43 : %d \n", b);

	printf("8���� 032 : %d \n", c);
	printf("8���� 024 : %d \n", d);

	printf("a-b=%d \n", a-b);
	printf("c+d=%d \n", c+d);
	printf("b*c=%d \n", b*c);

	return 0;
}