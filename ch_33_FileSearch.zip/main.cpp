#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#include <stdio.h>
#include <time.h>

#define  MAX_FILENAME	(_MAX_PATH + _MAX_DIR + _MAX_FNAME +_MAX_EXT)


char* McUtil_SimpleStrDateTime(char* sYear, char* sMonth, char* sDay, char* sTime, time_t lTime);

void GetAllFiles(char* sPath, int* nTot);
void FindFiles(char** &pFiles, int* nTot, char* sPath, char* sFile);



void main()
{
	int	i;
	
	char** pFiles=NULL;
	int nTot =0;
	
	FindFiles(pFiles, &nTot, "C:", "notepad.exe");

	if(nTot)
	{
		for(i=0; i<nTot; ++i)
			printf("%s\n", pFiles[i]);
	}
	else
	{
		printf("Find notepad.exe failed\n");
	}


	
	
	
	
	if(pFiles)
	{
		for(i=0; i<nTot; ++i)
			free( pFiles[i] );

		free(pFiles);

		pFiles = NULL;
	}
}



void GetAllFiles(char* sPath, int* nTot)
{
	char sSearchPath[2048];
	_finddata_t fd;
	long handle;

	int result=1;

	sprintf(sSearchPath,"%s/*.*", sPath);
	handle=_findfirst(sSearchPath,&fd);
	
	if (handle == -1)
		return;
	
	while (result != -1)
	{
		char sDate[128];
		char sYear[32];
		char sMonth[32];
		char sDay[32];
		char sTime[32];

		if(fd.name[0] !='.')
		{
			strcpy(sDate, McUtil_SimpleStrDateTime(sYear, sMonth, sDay, sTime, fd.time_write ) );
			printf("%s %s %s %s %9d %s %s\n", sYear, sMonth, sDay, sTime, fd.size, sPath, fd.name);

			if((fd.attrib & 0x10))
			{
				char sSearchFolder[2048];

				sprintf(sSearchFolder, "%s/%s", sPath, fd.name);
				GetAllFiles(sSearchFolder, nTot);
			}

			else
			{
				++(*nTot);
			}
		}
		
		result=_findnext(handle,&fd);
		
	}

	_findclose(handle);
	
}



void FindFiles(char** &pFiles, int* nTot, char* sPath, char* sFile)
{
	char sSearchPath[2048];

	_finddata_t fd;
	
	long handle;

	int result=1;

	sprintf(sSearchPath,"%s/*.*", sPath);
	
	
	handle=_findfirst(sSearchPath,&fd);
	
	if (handle == -1)
		return;
	
	while (result != -1)
	{
		if(fd.name[0] !='.')
		{
			if((fd.attrib & 0x10))
			{
				char sSearchFolder[2048];

				sprintf(sSearchFolder, "%s/%s", sPath, fd.name);
				FindFiles(pFiles, nTot, sSearchFolder, sFile);
			}

			else
			{
				if(0== _stricmp(fd.name, sFile))
				{
					char sYear[32];
					char sMonth[32];
					char sDay[32];
					char sTime[32];
					
					McUtil_SimpleStrDateTime(sYear, sMonth, sDay, sTime, fd.time_write);


					pFiles =(char**)realloc(pFiles, (*nTot+1) * sizeof(char*));
					pFiles[*nTot] = (char*)malloc( MAX_FILENAME * sizeof (char));
					sprintf(pFiles[*nTot], "%s %s %s %s %9d %s %s", sYear, sMonth, sDay, sTime, fd.size, sPath, fd.name);
					++(*nTot);
				}
			}
		}
		
		result=_findnext(handle,&fd);
		
	}

	_findclose(handle);
	
}



char* McUtil_SimpleStrDateTime(char* sYear, char* sMonth, char* sDay, char* sTime, time_t lTime)
{
	static char sTimeA[256];

	char C[64];
	char Y[16];
	char M[16];
	char D[16];
	char T[32];

	strcpy(C, ctime( &lTime ) );
	sscanf(C, "%*s %*s %*s %s", T);

	strftime( C, sizeof C, "%Y %m %d", gmtime(&lTime) );
	sscanf(C, "%s %s %s", Y, M, D);

	
	if(sYear)
		strcpy(sYear, Y);
	
	if(sMonth)
		strcpy(sMonth, M);

	if(sDay)
		strcpy(sDay, D);

	if(sTime)
		strcpy(sTime, T);


	memset(sTimeA, 0, sizeof sTimeA);
	sprintf(sTimeA, "%s %s %s %s", Y, M, D, T);

	return sTimeA;
}